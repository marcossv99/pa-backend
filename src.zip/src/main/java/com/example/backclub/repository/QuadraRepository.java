package com.example.backclub.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.backclub.domain.entity.Quadra;
public interface QuadraRepository extends JpaRepository<Quadra, Long> {
}
