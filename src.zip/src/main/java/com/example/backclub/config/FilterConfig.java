package com.example.backclub.config;

import org.springframework.context.annotation.Configuration;

@Configuration
public class FilterConfig {
    // Configuração de filtros removida temporariamente para simplificar testes
}
