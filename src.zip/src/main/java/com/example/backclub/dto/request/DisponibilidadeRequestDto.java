package com.example.backclub.dto.request;

import lombok.Data;

@Data
public class DisponibilidadeRequestDto {
    private boolean disponivel;
}
