package com.example.backclub.controller;

// Arquivo de exceção de autenticação temporariamente desabilitado

/*
public class AuthenticationException extends RuntimeException {
    public AuthenticationException(String message) {
        super(message);
    }
}
*/
