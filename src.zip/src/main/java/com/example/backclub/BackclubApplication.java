package com.example.backclub;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication()
public class BackclubApplication {

    public static void main(String[] args) {
        SpringApplication.run(BackclubApplication.class, args);
    }

}
